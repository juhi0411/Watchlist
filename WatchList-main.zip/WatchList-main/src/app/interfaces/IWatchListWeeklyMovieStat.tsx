export default interface IWatchListWeeklyMovieStat {
     Year: number,
     WeekNum: number
     MovieCount: number
}
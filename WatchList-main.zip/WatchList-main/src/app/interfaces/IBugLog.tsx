export default interface BugLog {
    WLBugID: number,
    WLBugName: string,
    AddDate: string,
    CompletedDate: string,
    ResolutionNotes: string,
}
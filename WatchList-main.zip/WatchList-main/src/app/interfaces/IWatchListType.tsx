export default interface WatchListType {
     WatchListTypeID: number,
     WatchListTypeName: string
}
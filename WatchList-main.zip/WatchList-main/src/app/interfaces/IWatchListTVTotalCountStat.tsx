export default interface IWatchListTVTotalCountStat {     
     TVTotalCount: number
}
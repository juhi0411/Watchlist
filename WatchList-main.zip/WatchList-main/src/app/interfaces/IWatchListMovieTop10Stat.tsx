export default interface IWatchListMovieTop10Stat {
     UserID: number,
     WatchListItemName: string,
     ItemCount: number,
     IMDB_URL: string
}
export default interface IWatchListTVSeasonsCountStat {     
     TVSeasonsCount: number
}
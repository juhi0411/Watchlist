export default interface IWatchListMovieCountStat {     
     MovieCount: number
}
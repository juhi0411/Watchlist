export default interface IRecommendation {
     Title: string,
     Year: string,
     ImdbID: string,
     Type: string,
     Poster: string
}
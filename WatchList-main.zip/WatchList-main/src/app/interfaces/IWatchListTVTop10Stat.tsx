export default interface IWatchListTVTop10Stat {
     UserID: number,
     WatchListItemName: string
     StartDate: string
     EndDate: string
     ItemCount: number,
     IMDB_URL: string
}
export default interface IWatchListSourceStat {
     WatchListSourceID: number,
     WatchListSourceName: string,
     SourceCount: number
}
export default interface IWatchListTopRatedStat {
     WatchListItemName: string,
     Season: number,
     Rating: number,
     IMDB_URL: string
}
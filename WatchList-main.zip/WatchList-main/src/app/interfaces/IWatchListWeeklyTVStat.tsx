export default interface IWatchListWeeklyTVStat {
     Year: number,
     WeekNum: number
     TVCount: number
}